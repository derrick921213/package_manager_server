#!/bin/bash
echo 您刚才输入的内容是: $1
